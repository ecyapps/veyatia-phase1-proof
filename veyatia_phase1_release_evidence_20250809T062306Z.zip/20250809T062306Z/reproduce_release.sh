#!/usr/bin/env bash
# Reproduction script for this release verification
set -euo pipefail

echo "🔄 Reproducing Phase 1 release verification"
echo "Original commit: bbdbbc7"
echo "Original tag: emotional-os-core-v1"
echo ""

# Checkout exact commit
if [[ "$(git rev-parse HEAD)" != "bbdbbc7c48071ee0d3bcf57742c83828c0dc06ac" ]]; then
    echo "⚠️  Current commit differs. Checking out bbdbbc7..."
    git checkout bbdbbc7c48071ee0d3bcf57742c83828c0dc06ac
fi

# Set environment
export PYTHONHASHSEED=0
export VEYATIA_SEED=42
export NUMPY_SEED=42

# Run the verification
echo "🔒 Running Phase 1 verification..."
./scripts/independent_verify.sh

echo "✅ Release verification complete"
